package com.zz.dao;

import com.zz.pojo.User;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    //获取全部用户
    List<User> getUserlist();

    //根据id查询用户 ，返回值是个用户
    User getUserByid(int id);

    //增加一个用户
    int addUser(User user);


    //修改用户信息
    int updataUser(User user);

     //删除用户信息
    int deletUser(int id);
}
