package com.zz.clien;

public interface rent {
    public void rent();
}
