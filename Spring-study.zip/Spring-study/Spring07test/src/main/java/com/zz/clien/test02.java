package com.zz.clien;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class test02 {
    @MyAnnotation(age=18)
    public void test(){
        //String name;
        //Class<?> aClass = Class.forName(com.zz.clien.Clien);
    }
}

@Target({ElementType.TYPE,ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface MyAnnotation{
    String name() default "";
    int age();
    int id() default 0;

    String []school() default {"西部开源","西工大","西电"};
}
