package com.zz.servlet;

import com.zz.pojo.User;
import com.zz.service.user.UserService;
import com.zz.service.user.UserServiceImpl;
import com.zz.util.Constants;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;



public class LoginServlet extends HttpServlet {
    //Servlet:控制层，调用业务层代码
    //private static final long serialVersionUID = -4672709233628500722L;
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("loginservlet -- start--");
        //获取用户名和密码
        String userCode = request.getParameter("userCode");//从页面获取账号和密码
        String userPassword = request.getParameter("userPassword");
        //
/*        System.out.println("-----------输出账号和密码----------");
        System.out.println(userCode);
        System.out.println(userPassword);
        System.out.println("-----------结束----------");*/

        //调用service方法，进行用户匹配
        UserService userService = new UserServiceImpl();
        User user = userService.login(userCode, userPassword);
        if (user != null) {//登录成功
            //放入session
            request.getSession().setAttribute(Constants.USER_SESSION, user);
            //页面重定向（frame.jsp）
            response.sendRedirect("jsp/frame.jsp");
        } else {
            //页面转发（login.jsp）带出提示信息--转发
            request.setAttribute("error", "用户名或密码不正确");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }

    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
