package com.zz.pojo;

public class UserT {
    private String name;

    public UserT() {
        System.out.printf("我是无参构造！Uset");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "UserT{" +
                "name='" + name + '\'' +
                '}';
    }
}
