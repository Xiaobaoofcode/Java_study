package com.zz.dao;

import com.zz.pojo.Student;

import java.util.List;

public interface StudentMapper {
    //返回学生列表和老师
    public List<Student> getStudent();

    public List<Student> getStudent2();
}
