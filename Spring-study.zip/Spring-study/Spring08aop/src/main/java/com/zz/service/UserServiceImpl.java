package com.zz.service;

public class UserServiceImpl implements UserService{
    @Override
    public void add() {
        System.out.println("我是增加一个用户！");
    }

    @Override
    public void delete() {
        System.out.println("我是删除一个用户！");
    }

    @Override
    public void update() {
        System.out.println("我是修改一个用户！");
    }

    @Override
    public void check() {
        System.out.println("我是检查一个用户！");
    }
}
