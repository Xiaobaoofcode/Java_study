package com.zz.dao;

import com.zz.pojo.Student;

import java.util.List;

public interface StudentMapper {
}
