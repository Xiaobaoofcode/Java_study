package com.zz.dao;

import com.zz.pojo.User;

import java.util.List;

public interface UserMapper {
    //查找用户
    public List<User> selectUser();

    //增加一个用户
    public int addUser(User user);
    //删除一个用户
    public int deleteUser(int id);
}
