package com.zz.service;

import com.zz.dao.UserOrcalImpl;
import com.zz.dao.Userdao;
import com.zz.dao.UserdaoImpl;

public class ServiceImpl implements Service{
    //需要引入dao层
    //private Userdao user = new UserOrcalImpl();//这里必须改变
    private Userdao userdao;

    //利用set动态注入
    public void setUserdao(Userdao userdao) {
        this.userdao = userdao;
    }

    @Override
    public void getMysql() {
        userdao.getMysql();
    }


}
