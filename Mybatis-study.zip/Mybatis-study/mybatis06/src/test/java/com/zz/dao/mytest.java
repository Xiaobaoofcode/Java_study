package com.zz.dao;

import com.zz.pojo.Student;
import com.zz.pojo.Teacher;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class mytest {
    @Test
    public void Test(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        TeacherMapper mapper = sqlsession.getMapper(TeacherMapper.class);

        Teacher teacher = mapper.getTeacher(1);
        System.out.println(teacher.getName());
        sqlsession.close();
    }

    @Test
    public void studenttest(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        StudentMapper mapper = sqlsession.getMapper(StudentMapper.class);
        List<Student> student = mapper.getStudent();
        for(Student student1:student){
            System.out.println(student1.toString());
        }
        sqlsession.close();
    }
    @Test
    public void studentest2(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        StudentMapper mapper = sqlsession.getMapper(StudentMapper.class);
        List<Student> student = mapper.getStudent2();
        for(Student student1:student){
            System.out.println(student1.toString());
        }
        sqlsession.close();
    }
}
