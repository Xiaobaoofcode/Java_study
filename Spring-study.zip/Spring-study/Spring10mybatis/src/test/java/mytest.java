import com.zz.dao.UserMapper;
import com.zz.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class mytest {
    @Test
    public void test() throws IOException {
//        String resouces = "mybatis-config.xml";
//        InputStream im = Resources.getResourceAsStream(resouces);
//
//        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(im);
//        SqlSession sqlSession = sessionFactory.openSession(true);
//
//        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
//        List<User> userList = mapper.selectUser();
        ApplicationContext context = new ClassPathXmlApplicationContext("application.xml");

        UserMapper userMapper = context.getBean("userMapper2", UserMapper.class);
        for (User user:userMapper.selectUser()){
            System.out.println(user);
        }
    }
}
