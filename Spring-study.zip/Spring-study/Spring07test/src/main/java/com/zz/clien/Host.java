package com.zz.clien;

public class Host implements rent{
    @Override
    public void rent() {
        System.out.printf("我是房东！");
    }
}
