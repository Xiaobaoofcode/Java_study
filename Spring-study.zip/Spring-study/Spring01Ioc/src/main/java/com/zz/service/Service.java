package com.zz.service;

public interface Service {
    void getMysql();

}
