package com.zz.dao;

import com.zz.pojo.Teacher;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;

public class Teachertest {
    public static void main(String[] args) {
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        TeacherMapper mapper = sqlsession.getMapper(TeacherMapper.class);

        Teacher teacher = mapper.getTeacher(1);
        System.out.println(teacher.getName());
        sqlsession.close();
    }
}
