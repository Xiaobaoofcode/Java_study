package com.zz.dao;

import com.zz.pojo.Teacher;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface TeacherMapper {
    //获取老师
//    List<Teacher> getTeacher();
    Teacher getTeacher(@Param("tid") int id);
}
