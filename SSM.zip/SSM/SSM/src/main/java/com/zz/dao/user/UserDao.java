package com.zz.dao.user;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.zz.pojo.User;

public interface UserDao {
    //查找用户是否已经存在
    public User getUsercode(Connection connection,String userCode);
    //得到要登录的用户
    public User getLoginUser(Connection connection, String userCode,String userPassword);
    //修改用户的密码
    public int UpdatePwd(Connection connection,int id,String userPassword);

    /* 通过条件查询-用户表记录数
     */
    public int getUserCount(Connection connection, String userName, int userRole) throws SQLException;

    /*获取用户列表*/
    public  List<User> getUserList(Connection connection, String userName, int userRole, int currentPageNo, int pageSize) throws Exception;


    //删除用户
    public int deleteUserById(Connection connection,Integer usrid);

    //增加用户
    public int add(Connection connection,User user);


   // User getLoginUser(Connection connection, String userCode);
    /**
     * 通过userId获取user
     */
    User getUserById(Connection connection, String id) throws Exception;

    /**
     * 修改用户信息
     */
    int modify(Connection connection, User user) throws Exception;

}
