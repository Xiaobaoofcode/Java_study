##常用的包
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-webmvc</artifactId>
            <version>5.3.3</version>
        </dependency>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
        </dependency>

##常用的注解
-@Autowired:自动装配通过类型，名字
-@Nullable:字段标记了这个注解，说明这个字段可以为空
-@Resource:自动装配通过名字，类型
-@Component:组件，放在类上，说明这个类被Spring