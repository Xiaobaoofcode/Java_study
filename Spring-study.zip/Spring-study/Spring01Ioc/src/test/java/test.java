import com.zz.dao.UserOrcalImpl;
import com.zz.dao.UserdaoImpl;
import com.zz.service.Service;
import com.zz.service.ServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class test {
    public static void main(String[] args) {
//        ServiceImpl service = new ServiceImpl();
//        service.setUserdao(new UserOrcalImpl());
//        service.getMysql();
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

        Service serviceImpl = (Service) context.getBean("ServiceImpl");
        serviceImpl.getMysql();
    }
}
