package com.zz.dao;

public interface Userdao {
    //
     void getMysql();
}
