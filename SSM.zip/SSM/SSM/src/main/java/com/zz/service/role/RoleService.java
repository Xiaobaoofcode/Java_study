package com.zz.service.role;

import com.zz.pojo.Role;

import java.util.List;

public interface RoleService {
    /**
     * 获取角色列表
     *
     * @return
     */
    public List<Role> getRoleList();
}
