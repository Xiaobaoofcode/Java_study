package com.zz.service.user;

import com.zz.pojo.User;

import java.sql.SQLException;
import java.util.List;

public interface UserService {
    //判断用户是否已经存在
    public  User getUsercode(String userCode);
    //用户登录
    public User login(String userCode, String userPassword);
    //根据用户id修改密码
    public  boolean UpdataPwd(int id,String userPassword);

    //根据条件查询用户表记录数
    public int getUserCount(String queryUserName, int queryUserRole) throws SQLException;

    //根据条件查询用户
    public List<User> getUserList(String queryUserName, int queryUserRole, int currentPageNo, int pageSize);


    //根据用户的id删除用户的信息
    public boolean delusrbyid(Integer usrid);

    //增加用户信息
    public boolean add(User user);

    /**
     * 根据userCode查询出User
     */
    public User selectUserCodeExist(String userCode,String userPassword);

    /**
     * 根据ID查找user
     */
    public User getUserById(String id);

    /**
     * 修改用户信息
     */
    public boolean modify(User user);
}
