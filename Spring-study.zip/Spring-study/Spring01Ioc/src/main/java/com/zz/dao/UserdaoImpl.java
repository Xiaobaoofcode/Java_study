package com.zz.dao;

public class UserdaoImpl implements Userdao{
    @Override
    public void getMysql() {
        System.out.printf("我是mysql数据库！");
    }
}
