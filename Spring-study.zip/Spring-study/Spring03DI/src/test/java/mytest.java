import com.zz.pojo.Student;
import com.zz.pojo.User;
import com.zz.pojo.Usertest;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RestController;

public class mytest {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

        Student student = (Student) context.getBean("student");
        System.out.printf(student.toString());//student.getName();
    }

    @Test
    public void test(){
        ApplicationContext context = new ClassPathXmlApplicationContext("Userbeans.xml");
        Usertest user = context.getBean("user2", Usertest.class);
        System.out.printf(user.toString());
    }
}
