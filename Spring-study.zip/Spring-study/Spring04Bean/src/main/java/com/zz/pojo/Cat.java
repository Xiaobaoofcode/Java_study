package com.zz.pojo;

public class Cat {
    public void getcatshow(){
        System.out.printf("我是猫，我会喵！");
    }
}
