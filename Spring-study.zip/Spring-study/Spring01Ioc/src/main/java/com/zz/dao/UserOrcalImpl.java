package com.zz.dao;

public class UserOrcalImpl implements Userdao{
    @Override
    public void getMysql() {
        System.out.printf("我是Orcal数据库");
    }
}
