package com.zz.service.user;

import com.zz.dao.BaseDao;
import com.zz.dao.user.UserDao;
import com.zz.dao.user.UserDaoImpl;
import com.zz.pojo.User;

import java.sql.Connection;
import java.sql.ParameterMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class UserServiceImpl implements UserService{


    //业务层调用Dao层，所以我们要引入Dao层
    private UserDao userDao;

    public UserServiceImpl() {
        userDao = new UserDaoImpl();
    }

    //判断用户是否存在
    @Override
    public User getUsercode(String userCode) {
        Connection connection = null;
        User user = null;
        try {
            connection = BaseDao.getConnection();
            //通过业务层调用对应的具体数据库操作
            user = userDao.getUsercode(connection, userCode);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        return user;
    }

    //登陆
    @Override
    public User login(String userCode, String userPassword) {
        Connection connection = null;
        User user = null;
        try {
            connection = BaseDao.getConnection();
            //通过业务层调用对应的具体数据库操作
            user = userDao.getLoginUser(connection, userCode,userPassword);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        return user;
    }

    //修改密码
    @Override
    public boolean UpdataPwd(int id, String userPassword) {
        boolean flag = false;
        Connection connection = null;
        try {
            connection = BaseDao.getConnection();//建立连接
            if (userDao.UpdatePwd(connection, id,userPassword ) > 0) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        return flag;
    }

    //获取用户总数service
    @Override
    public int getUserCount(String queryUserName, int queryUserRole) throws SQLException {
        //
        Connection connection = null;
        int count = 0;
        try {
            connection = BaseDao.getConnection();
            count = userDao.getUserCount(connection, queryUserName, queryUserRole);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            BaseDao.closeResource(connection, null, null);
        }
        return count;
    }

    //根据用户获取用户列表

    @Override
    public List<User> getUserList(String queryUserName, int queryUserRole, int currentPageNo, int pageSize) {
        //
        Connection connection = null;
        List<User> userList = null;
        try{
            connection = BaseDao.getConnection();
            userList = userDao.getUserList(connection,queryUserName, queryUserRole, currentPageNo, pageSize);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            BaseDao.closeResource(connection,null,null);
        }
        return userList;
    }

    //删除用户
    @Override
    public boolean delusrbyid(Integer usrid) {
        Connection connection = null;
        boolean flag = false;
        try{
            connection = BaseDao.getConnection();//获取链接
            //判断需要删除的用户是否合法
            if (userDao.deleteUserById(connection, usrid) > 0) {
                flag = true;
            }

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            BaseDao.closeResource(connection,null,null);
        }
        return flag;
    }

    //增加用户
    @Override
    public boolean add(User user) {
        boolean flag = false;
        Connection connection = null;
        try{
            connection = BaseDao.getConnection();//获得链接
            connection.setAutoCommit(false);//开启jdbc事物管理
            int updateRows = userDao.add(connection,user);
            connection.commit();
            if(updateRows>0){
                flag = true;
                System.out.printf("add success!");
            }else {
                System.out.printf("add failed!");
            }
        }catch (Exception e){
            e.printStackTrace();
            try{
                connection.rollback();//如果出错就回滚
            }catch (SQLException e1){
                e1.printStackTrace();
            }
        }finally {
            BaseDao.closeResource(connection,null,null);
        }
        return flag;
    }

    // 根据userCode查询出User
    @Override
    public User selectUserCodeExist(String userCode,String userPassword) {
        Connection connection = null;
        User user = null;
        try {
            connection = BaseDao.getConnection();
            user = userDao.getLoginUser(connection, userCode,userPassword);
            System.out.printf("你好啊"+user+"wohao");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        return user;
    }

    //
    @Override
    public User getUserById(String id) {
        // TODO Auto-generated method stub
        User user = null;
        Connection connection = null;
        try {
            connection = BaseDao.getConnection();
            user = userDao.getUserById(connection, id);
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            user = null;
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        return user;
    }

    //修改用户数据
    @Override
    public boolean modify(User user) {
        // TODO Auto-generated method stub
        Connection connection = null;
        boolean flag = false;
        try {
            connection = BaseDao.getConnection();
            if (userDao.modify(connection, user) > 0) {
                flag = true;
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            BaseDao.closeResource(connection, null, null);
        }
        return flag;
    }


}
