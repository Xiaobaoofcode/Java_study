package com.zz.dao.role;

import com.zz.pojo.Role;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface RoleDao {
    /**
     * 获取角色列表
     *
     * @param connection
     * @return
     * @throws Exception
     */
   public List<Role> getRoleList(Connection connection) throws SQLException;
}
