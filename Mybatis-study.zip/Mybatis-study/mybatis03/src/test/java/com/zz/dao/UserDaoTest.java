package com.zz.dao;

import com.zz.pojo.User;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class UserDaoTest {
    static Logger logger = Logger.getLogger(UserDaoTest.class);

    @Test
    public void getUserlike(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        List<User> userlike = mapper.getUserlist();
        for(User user:userlike){
            System.out.println(user.password);
        }
        sqlsession.close();
    }

    @Test
    public void getUserByid(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        User user = mapper.getUserByid(3);

        System.out.println(user.password);

        sqlsession.close();
    }

    @Test
    public void testlog(){
        logger.info("info:进入了info的testlog4j");
    }

    @Test
    public void getUserBylimit(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);
        Map<String,Integer> map= new HashMap<String,Integer>();
        map.put("startIndex",0);
        map.put("pageSize",2);

        List<User> userBylimit = mapper.getUserBylimit(map);
        for(User user:userBylimit){
            System.out.println(user.password);
        }
        sqlsession.close();
    }

    @Test
    public void getUserByRowBounds(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        //RowBounds实现
        RowBounds rowBounds = new RowBounds(1, 2);


        //通过java代码实现分页
        List<User> userList = sqlsession.selectList("com.zz.dao.UserMapper.getUserByRowBounds",0,rowBounds);
        for(User user:userList){
            System.out.println(user.password);
        }
        sqlsession.close();
    }
}
