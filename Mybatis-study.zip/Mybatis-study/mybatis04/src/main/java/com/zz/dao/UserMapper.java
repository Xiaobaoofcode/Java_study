package com.zz.dao;

import com.zz.pojo.User;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    @Select("select *from mybatis.user")
    List<User> getUser();

    //方法存在多个参数，所有的参数前面必须要家@Param("")注解
    @Select("select *from mybatis.user where id = #{id}")
    User getUserByid(@Param("id")int id);

    //增加用户信息
    @Insert("insert into user(id,name,pwd) values(#{id},#{name},#{password})")
    int addUser(User user);

    //修改用户信息
    @Update("updata user set name=#{name},pwd=#{password} where id=#{id}")
    int updataUser(User user);

    //删除用户信息
    @Delete("delete from user where id=#{uid}")
    int deleteUser(@Param("uid") int id);
}
