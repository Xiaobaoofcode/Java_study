package com.zz.dao;

import com.zz.pojo.User;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionManager;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserDaoTest {

    @Test
    public void getUserlike(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        List<User> userlike = mapper.getUserlike("%地%");
        for(User user:userlike){
            System.out.println(user.pwd);
        }

        sqlsession.close();
    }
    @Test
    public void  test(){
        //获得sqlSession对象
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        //执行sql
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);
        List<User> userlist = mapper.getUserlist();

        for(User user:userlist){
            System.out.println(user.pwd);
        }

        //关闭SqlSession
        sqlsession.close();
    }

    @Test
    public  void getUserByid(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        User user= mapper.getUserByid(1);
        System.out.printf(user.pwd);

        sqlsession.close();//关闭资源

    }

    @Test
    public void addUser(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();

        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        int i = mapper.addUser(new User(8, "中国", "12313"));

        if(i>0){
            System.out.printf("增加成功！");
        }
        //增删改 一定一定要提交事物！
        sqlsession.commit();
        sqlsession.close();

    }

    @Test
    public void addUser2(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();

        UserMapper mapper = sqlsession.getMapper(UserMapper.class);
        Map<String,Object> map = new HashMap<>();
        map.put("userid",9);
        map.put("username","地理");
        map.put("userpwd","zz12323");
        int i = mapper.addUser2(map);
        //int i = mapper.addUser(new User(4, "中国", "12313"));

        if(i>0){
            System.out.printf("增加成功！");
        }
        //增删改 一定一定要提交事物！
        sqlsession.commit();
        sqlsession.close();

    }

    @Test
    public void updataUser(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        int i = mapper.updataUser(new User(4, "中国你好！", "zz123"));

        if(i>0){
            System.out.printf("修改成功！");
        }
        sqlsession.commit();//提交事物
        sqlsession.close();//关闭资源
    }

    @Test
    public void deletUser(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);

        int i = mapper.deletUser(2);
        if(i>0){

        }

        sqlsession.commit();
        sqlsession.close();
    }
}
