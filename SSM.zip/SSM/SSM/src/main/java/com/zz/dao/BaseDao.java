package com.zz.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

//操作数据库的公共类
public class BaseDao {
    private static String driver;
    private static String url;
    private static String username;
    private static String password;


    //静态代码块,在类加载的时候执行
    static {
        Properties params = new Properties();
        String configFile = "db.properties";
        //通过类加载器获取对应的资源
        InputStream is = BaseDao.class.getClassLoader().getResourceAsStream(configFile);
        try {
            params.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
        driver = params.getProperty("driver");
        url = params.getProperty("url");
        username = params.getProperty("username");
        password = params.getProperty("password");
    }


    /**
     * 获取数据库连接
     *
     * @return
     */
    public static Connection getConnection() {
        //Connection代表一个JDBC连接，它相当于Java程序到数据库的连接（通常是TCP连接）
        Connection connection = null;
        try {
            Class.forName(driver);
            // 获取连接:
            connection = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * 查询数据库的公共操作
     * 查找
     * @param connection
     * @param pstm
     * @param rs
     * @param sql
     * @param params
     * @return
     */
    public static ResultSet execute(Connection connection, PreparedStatement pstm, ResultSet rs,
                                    String sql, Object[] params) {
        try {
            pstm = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {//必须首先调用setObject()设置每个占位符?的值
                //索引从1开始 有几个?占位符就必须设置对应的参数。
                pstm.setObject(i + 1, params[i]);
            }
            rs = pstm.executeQuery();//执行查询并获得返回的结果集，使用ResultSet来引用这个结果集；
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return rs;
    }

    /**
     * 更新数据库的公共操作
     * 增加删除修改
     * @param connection
     * @param pstm
     * @param sql
     * @param params
     * @return
     * @throws Exception
     */
    public static int execute(Connection connection, PreparedStatement pstm, String sql,
                              Object[] params) {
        int updateRows = 0;
        try {
            pstm = connection.prepareStatement(sql);
            for (int i = 0; i < params.length; i++) {
                pstm.setObject(i + 1, params[i]);
            }
            updateRows = pstm.executeUpdate();// 返回更新的行数
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return updateRows;
    }

    /**
     * 释放资源
     *
     * @param connection
     * @param pstm
     * @param rs
     * @return
     */
    public static boolean closeResource(Connection connection, PreparedStatement pstm, ResultSet rs) {
        boolean flag = true;
        if (rs != null) {
            try {
                rs.close();
                rs = null;//GC回收
            } catch (SQLException e) {
                e.printStackTrace();
                flag = false;
            }
        }
        if (pstm != null) {
            try {
                pstm.close();
                pstm = null;//GC回收
            } catch (SQLException e) {
                e.printStackTrace();
                flag = false;
            }
        }
        if (connection != null) {
            try {
                connection.close();
                connection = null;//GC回收
            } catch (SQLException e) {
                e.printStackTrace();
                flag = false;
            }
        }
        return flag;
    }

}
