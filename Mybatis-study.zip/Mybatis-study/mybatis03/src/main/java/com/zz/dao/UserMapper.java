package com.zz.dao;

import com.zz.pojo.User;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    //获取全部用户
    List<User> getUserlist();

    //根据id查询用户 ，返回值是个用户
    User getUserByid(int id);

    //分页
    List<User> getUserBylimit(Map<String,Integer> map);

    List<User> getUserByRowBouds();

}
