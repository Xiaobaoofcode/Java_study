package com.zz.config;

import com.zz.pojo.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.zz.pojo")
public class Userconfig {

    @Bean //这个方法的名字就相当于bean标签的id属性  方法的返回值相当于bean标签中的clss、属性
    public User getUser(){
        return new User();
    }
}
