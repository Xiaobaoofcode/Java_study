package com.zz.dao;

import com.zz.pojo.User;
import org.apache.ibatis.annotations.Param;

public interface UserMapper {
    //查询数据
    User getUserByid(@Param("id") int id);

    //更新数据
    int updateByid(User user);
}
