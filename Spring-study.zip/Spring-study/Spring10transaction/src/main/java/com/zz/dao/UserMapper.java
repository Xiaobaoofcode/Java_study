package com.zz.dao;

import com.zz.pojo.User;

import java.util.List;

public interface UserMapper {
    public List<User> selectUser();
}
