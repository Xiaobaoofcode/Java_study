package com.zz.dao;

import com.zz.pojo.User;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class UserMapperImpl extends SqlSessionDaoSupport implements UserMapper{

    public List<User> selectUser() {
        //return null;
        return getSqlSession().getMapper(UserMapper.class).selectUser();
    }

}
