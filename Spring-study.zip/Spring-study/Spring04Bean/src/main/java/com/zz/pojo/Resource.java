package com.zz.pojo;

public @interface Resource {
}
