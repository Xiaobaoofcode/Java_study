package com.zz.dao;

import com.zz.pojo.Blog;

import java.util.List;
import java.util.Map;

public interface BlogMapper {
    //插入数据
    int addBlog(Blog blog);

    //查询
    List<Blog> getBolgBytitle(Map map);

    //查询choose
    List<Blog> getBlogBytitle(Map map);

    //更新数据
    int updataBlog(Map map);

    //查询1-2-3的blog
    List<Blog> queryBlogForeach(Map map);
}
