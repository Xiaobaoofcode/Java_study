package com.zz.dao;

import com.zz.pojo.User;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class mytest {
    @Test
    public void test1(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        SqlSession sqlsession1 = MybatisUtils.getSqlsession();

        UserMapper mapper = sqlsession.getMapper(UserMapper.class);
        UserMapper mapper1 = sqlsession1.getMapper(UserMapper.class);

        User userByid = mapper.getUserByid(2);
        System.out.println(userByid.toString());

        //修改1
        //mapper.updateByid(new User(1,"你好","dasds"));
        System.out.println("第一次获取后，查询第二次，查看是否再次查询？");
        sqlsession.close();

        User userByid1 = mapper1.getUserByid(2);

        System.out.println(userByid1.toString());
        System.out.printf(String.valueOf(userByid.equals(userByid1)));
        sqlsession1.close();
    }
}
