package com.zz.pojo;

import com.zz.config.Userconfig;
import org.junit.Test;
import org.springframework.aop.support.annotation.AnnotationClassFilter;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class test {
    public static void main(String[] args) {

        ApplicationContext context = new AnnotationConfigApplicationContext(Userconfig.class);
        User user = context.getBean("user", User.class);
        System.out.printf(user.getName());
    }

}
