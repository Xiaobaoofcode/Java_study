package com.zz.dao;

import com.zz.pojo.Blog;
import com.zz.utils.IDutils;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.*;

public class mytest {
    @Test
    public void addInitBlog(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        BlogMapper mapper = sqlsession.getMapper(BlogMapper.class);

        Blog blog = new Blog();
        blog.setId(IDutils.getId());
        blog.setTitle("mybatis如此简单");
        blog.setAuthor("主打歌");
        blog.setCreatetime(new Date());
        blog.setViews(998);

        mapper.addBlog(blog);

        blog.setId(IDutils.getId());
        blog.setTitle("python如此简单");
        mapper.addBlog(blog);

        blog.setId(IDutils.getId());
        blog.setTitle("c如此简单");
        mapper.addBlog(blog);

        blog.setId(IDutils.getId());
        blog.setTitle("c++如此简单");
        mapper.addBlog(blog);

        blog.setId(IDutils.getId());
        blog.setTitle("java如此简单");
        mapper.addBlog(blog);

        sqlsession.close();

    }

    @Test
    public void test(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        BlogMapper mapper = sqlsession.getMapper(BlogMapper.class);

        HashMap hashmap = new HashMap();
        hashmap.put("title","mybatis如此简单");
        hashmap.put("author","林心如");
        hashmap.put("views",989);
        hashmap.put("id","a6a0b847c72749bdb1c16a99f1ee832a");
        List<Blog> bolgBytitle = mapper.getBolgBytitle(hashmap);
        //List<Blog> blogBytitle = mapper.getBlogBytitle(hashmap);
        mapper.updataBlog(hashmap);
//        for(Blog blog:blogBytitle){
//            System.out.println(blog.toString());
//        }

        sqlsession.close();
    }

    @Test
    public void test2(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        BlogMapper mapper = sqlsession.getMapper(BlogMapper.class);

        Map map =  new HashMap();

        ArrayList<Integer> integers = new ArrayList<>();
        integers.add(1);
        integers.add(2);
        map.put("ids",integers);
        List<Blog> blogs = mapper.queryBlogForeach(map);

        for(Blog blog:blogs){
            System.out.printf(blog.toString());
        }

        sqlsession.close();
    }

}
