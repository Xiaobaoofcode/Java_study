package com.zz.clien;

public class Proxy implements rent{
    private Host host;

    public Proxy() {
    }

    public Proxy(Host host) {
        this.host = host;
    }
    public void rent(){
        seeHouse();
        host.rent();
        hetong();
        fare();
    }
    //看房
    public void seeHouse(){
        System.out.printf("中介带你看房！");
    }

    //看房
    public void hetong(){
        System.out.printf("等待租房合同！");
    }
    //收中介费
    public void fare(){
        System.out.printf("收中介费！");
    }
}
