package com.zz.dao;

import com.zz.pojo.User;
import com.zz.utils.MybatisUtils;
import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.junit.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class UserDaoTest {
    static Logger logger = Logger.getLogger(UserDaoTest.class);

    @Test
    public void getUserlike(){
        SqlSession sqlsession = MybatisUtils.getSqlsession();
        UserMapper mapper = sqlsession.getMapper(UserMapper.class);
//        //底层主要应用反射
//        List<User> userlike = mapper.getUser();
//        for(User user:userlike){
//            System.out.println(user.getName());
//        }
//        User userByid = mapper.getUserByid(1);
        int i = mapper.addUser(new User(11, "中国好", "zz331"));
        System.out.println(i);
        sqlsession.close();
    }
}
