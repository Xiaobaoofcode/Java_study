package com.zz.pojo;

public class Dog {
    public void getdogshow(){
        System.out.printf("我是狗，我会汪！");
    }
}
