package com.zz.dao;

import com.zz.pojo.User;

import java.util.List;
import java.util.Map;

public interface UserMapper {

    //模糊查询
    List<User> getUserlike(String value);

    //获取全部用户
    List<User> getUserlist();

    //根据id查询用户 ，返回值是个用户
    User getUserByid(int id);


    //User getUserByid2(Map<String,Object> map);

    //增加一个用户
    int addUser(User user);

    //用万能的map
    int addUser2(Map<String,Object> map);

    //修改用户信息
     int updataUser(User user);

     //删除用户信息
    int deletUser(int id);

}
